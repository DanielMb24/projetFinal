package com.example.topquiz.calculatrice.controller;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.topquiz.R;

public class CalculatorActivity extends AppCompatActivity {
    private TextView mHistoryTextView;
    private TextView mResultTextView;
    private double mValue1 = 0, mValue2 = 0;
    private String mOperator = "";
    private StringBuilder mCurrentInput = new StringBuilder();
    private StringBuilder mHistory = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        mHistoryTextView = findViewById(R.id.history_textview);
        mResultTextView = findViewById(R.id.result_textview);

        // Initialize number buttons (0-9)
        for (int i = 0; i <= 9; i++) {
            int id = getResources().getIdentifier("button_" + i, "id", getPackageName());
            int finalI = i;
            findViewById(id).setOnClickListener(v -> appendNumber(String.valueOf(finalI)));
        }

        findViewById(R.id.button_decimal).setOnClickListener(v -> appendDecimal());
        findViewById(R.id.button_plus).setOnClickListener(v -> setOperator("+"));
        findViewById(R.id.button_minus).setOnClickListener(v -> setOperator("-"));
        findViewById(R.id.button_multiply).setOnClickListener(v -> setOperator("*"));
        findViewById(R.id.button_divide).setOnClickListener(v -> setOperator("/"));
        findViewById(R.id.button_equals).setOnClickListener(v -> calculate());
        findViewById(R.id.button_clear).setOnClickListener(v -> clear());
    }

    private void appendNumber(String number) {
        mCurrentInput.append(number);
        mResultTextView.setText(mCurrentInput.toString());
    }

    private void appendDecimal() {
        if (!mCurrentInput.toString().contains(".")) {
            if (mCurrentInput.length() == 0) mCurrentInput.append("0");
            mCurrentInput.append(".");
            mResultTextView.setText(mCurrentInput.toString());
        }
    }

    private void setOperator(String operator) {
        if (mCurrentInput.length() > 0) {
            mValue1 = Double.parseDouble(mCurrentInput.toString());
            mOperator = operator;
            mCurrentInput.setLength(0);
            mResultTextView.setText("");
        }
    }

    private void calculate() {
        if (mCurrentInput.length() > 0 && !mOperator.isEmpty()) {
            try {
                mValue2 = Double.parseDouble(mCurrentInput.toString());
                double result = 0;
                switch (mOperator) {
                    case "+": result = mValue1 + mValue2; break;
                    case "-": result = mValue1 - mValue2; break;
                    case "*": result = mValue1 * mValue2; break;
                    case "/": if (mValue2 == 0) throw new ArithmeticException("Division by zero"); result = mValue1 / mValue2; break;
                }
                mHistory.append(mValue1).append(" ").append(mOperator).append(" ").append(mValue2).append(" = ").append(result).append("\n");
                mHistoryTextView.setText(mHistory.toString());
                mResultTextView.setText(String.valueOf(result));
                mValue1 = result;
                mOperator = "";
                mCurrentInput.setLength(0);
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
                clear();
            }
        }
    }

    private void clear() {
        mValue1 = 0;
        mValue2 = 0;
        mOperator = "";
        mCurrentInput.setLength(0);
        mHistory.setLength(0);
        mResultTextView.setText("");
        mHistoryTextView.setText("");
    }
}