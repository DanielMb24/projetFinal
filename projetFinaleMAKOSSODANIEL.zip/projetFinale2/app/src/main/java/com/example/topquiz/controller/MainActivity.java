package com.example.topquiz.controller;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.example.topquiz.R;

import com.example.topquiz.calculatrice.controller.CalculatorActivity;
import com.example.topquiz.model.User;

public class MainActivity extends AppCompatActivity {
    private TextView mGreetingTextView;
    private EditText mNameEditText;
    private User mUser;
    private SwitchCompat mThemeSwitch;

    private static final int GAME_ACTIVITY_REQUEST_CODE = 42;
    private static final String SHARED_PREF_USER_INFO = "SHARED_PREF_USER_INFO";
    private static final String SHARED_PREF_USER_INFO_NAME = "SHARED_PREF_USER_INFO_NAME";
    private static final String SHARED_PREF_USER_INFO_SCORE = "SHARED_PREF_USER_INFO_SCORE";
    private static final String SHARED_PREF_THEME = "SHARED_PREF_THEME";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mGreetingTextView = findViewById(R.id.main_textview_greeting);
        mNameEditText = findViewById(R.id.main_edittext_name);
        mThemeSwitch = findViewById(R.id.theme_switch);

        mUser = new User();

        SharedPreferences preferences = getSharedPreferences(SHARED_PREF_USER_INFO, MODE_PRIVATE);
        String firstName = preferences.getString(SHARED_PREF_USER_INFO_NAME, null);
        int score = preferences.getInt(SHARED_PREF_USER_INFO_SCORE, -1);
        boolean isDarkMode = preferences.getBoolean(SHARED_PREF_THEME, false);

        if (firstName != null && score != -1) {
            String welcomeMessage = "Bon retour " + firstName + " !\nVotre dernier score est " + score + ", prêt à faire mieux ?";
            mGreetingTextView.setText(welcomeMessage);
            mNameEditText.setText(firstName);
            mNameEditText.setSelection(firstName.length());
        }

        AppCompatDelegate.setDefaultNightMode(isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
        mThemeSwitch.setChecked(isDarkMode);
        mThemeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AppCompatDelegate.setDefaultNightMode(isChecked ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
            preferences.edit().putBoolean(SHARED_PREF_THEME, isChecked).apply();
            recreate();
        });

        findViewById(R.id.app_quiz).setOnClickListener(v -> {
            mUser.setFirstName(mNameEditText.getText().toString());
            startActivityForResult(new Intent(this, GameActivity.class), GAME_ACTIVITY_REQUEST_CODE);
        });
        findViewById(R.id.app_calculator).setOnClickListener(v -> startActivity(new Intent(this, CalculatorActivity.class)));
        findViewById(R.id.app_todo).setOnClickListener(v -> showAppInfo("To-Do List", "Ajout, marquage et suppression de tâches", R.string.in_development));
        findViewById(R.id.app_contacts).setOnClickListener(v -> showAppInfo("Carnet de Contacts", "Ajout, vue et suppression de contacts", R.string.in_development));
        findViewById(R.id.app_notes).setOnClickListener(v -> showAppInfo("Bloc-Notes", "Prise et sauvegarde de notes", R.string.in_development));
        findViewById(R.id.app_timer).setOnClickListener(v -> showAppInfo("Chronomètre", "Chronomètre et minuteur réglable", R.string.in_development));
        findViewById(R.id.app_converter).setOnClickListener(v -> showAppInfo("Convertisseur", "Conversion d'unités/devises", R.string.in_development));
        findViewById(R.id.app_music).setOnClickListener(v -> showAppInfo("Lecteur de Musique", "Lecture de fichiers MP3 locaux", R.string.in_development));
        findViewById(R.id.app_weather).setOnClickListener(v -> showAppInfo("Météo", "Affichage de la température par ville", R.string.in_development));
        findViewById(R.id.app_expenses).setOnClickListener(v -> showAppInfo("Suivi des Dépenses", "Ajout et total des dépenses", R.string.in_development));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (GAME_ACTIVITY_REQUEST_CODE == requestCode && RESULT_OK == resultCode) {
            int score = data.getIntExtra(GameActivity.BUNDLE_EXTRA_SCORE, 0);
            String firstName = mNameEditText.getText().toString();
            SharedPreferences preferences = getSharedPreferences(SHARED_PREF_USER_INFO, MODE_PRIVATE);
            preferences.edit()
                    .putString(SHARED_PREF_USER_INFO_NAME, firstName)
                    .putInt(SHARED_PREF_USER_INFO_SCORE, score)
                    .apply();
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Bravo " + firstName + " !")
                    .setMessage("Votre score est de " + score + " points.")
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    private void showAppInfo(String title, String features, int messageId) {
        new android.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(features + "\n\n" + getString(messageId))
                .setPositiveButton("OK", null)
                .show();
    }
}