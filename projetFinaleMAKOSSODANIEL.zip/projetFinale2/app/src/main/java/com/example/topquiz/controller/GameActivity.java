package com.example.topquiz.controller;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.topquiz.R;
import com.example.topquiz.model.Question;
import com.example.topquiz.model.QuestionBank;
import java.util.Arrays;

public class GameActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView mQuestionTextView;
    private Button mAnswerButton1;
    private Button mAnswerButton2;
    private Button mAnswerButton3;
    private Button mAnswerButton4;
    private int mRemainingQuestionCount;
    private Question mCurrentQuestion;
    private int mScore;

    public static final String BUNDLE_EXTRA_SCORE = "BUNDLE_EXTRA_SCORE";
    private final QuestionBank mQuestionBank = generateQuestions();
    private boolean mEnableTouchEvents;

    public static final String BUNDLE_STATE_SCORE = "BUNDLE_STATE_SCORE";
    public static final String BUNDLE_STATE_QUESTION = "BUNDLE_STATE_QUESTION";

    private QuestionBank generateQuestions() {
        Question q1 = new Question("Quel est le rôle principal d’un serveur DNS ?",
                Arrays.asList("Attribuer des adresses IP", "Traduire des noms de domaine en adresses IP", "Stocker des fichiers", "Analyser le trafic réseau"), 1);
        Question q2 = new Question("Quel protocole est utilisé pour sécuriser les communications web ?",
                Arrays.asList("HTTP", "FTP", "SSH", "HTTPS"), 3);
        Question q3 = new Question("Lequel des éléments suivants est un système d'exploitation libre ?",
                Arrays.asList("Windows", "macOS", "Linux", "iOS"), 2);
        Question q4 = new Question("Quel est le rôle d’un compilateur ?",
                Arrays.asList("Exécuter du code", "Analyser des données", "Traduire du code source en langage machine", "Gérer les réseaux"), 2);
        Question q5 = new Question("Quel langage est interprété parmi les suivants ?",
                Arrays.asList("C", "Python", "C++", "Java (en mode compilé)"), 1);
        Question q6 = new Question("Dans un réseau informatique, que signifie le terme 'bande passante' ?",
                Arrays.asList("Capacité de stockage", "Vitesse de transfert des données", "Nombre d'utilisateurs", "Fréquence de signal"), 1);
        Question q7 = new Question("Quelle est la commande Linux pour lister les fichiers d’un répertoire ?",
                Arrays.asList("list", "ls", "show", "dir"), 1);
        Question q8 = new Question("Quel est le rôle d’un routeur dans un réseau ?",
                Arrays.asList("Connecter des imprimantes", "Attribuer des adresses MAC", "Acheminer les paquets entre les réseaux", "Chiffrer les données"), 2);
        Question q9 = new Question("Quel outil est souvent utilisé pour tester la sécurité d’un réseau ?",
                Arrays.asList("Photoshop", "Nmap", "Audacity", "Visual Studio"), 1);
        Question q10 = new Question("Lequel est un langage de requête pour base de données relationnelle ?",
                Arrays.asList("HTML", "CSS", "SQL", "XML"), 2);
        Question q11 = new Question("Quel est le rôle principal d’un pare-feu ?",
                Arrays.asList("Imprimer les documents", "Sécuriser les connexions sans fil", "Filtrer le trafic réseau", "Optimiser le stockage"), 2);
        Question q12 = new Question("Quelle extension de fichier indique un exécutable Windows ?",
                Arrays.asList(".exe", ".txt", ".docx", ".html"), 0);
        Question q13 = new Question("Quel langage est souvent utilisé pour écrire des scripts shell ?",
                Arrays.asList("C", "Java", "Bash", "Perl"), 2);
        Question q14 = new Question("Quel service en ligne est un exemple de cloud computing ?",
                Arrays.asList("Microsoft Word", "Adobe Reader", "Google Drive", "WinRAR"), 2);
        Question q15 = new Question("Quel logiciel est une distribution Linux ?",
                Arrays.asList("Fedora", "macOS", "Windows XP", "DOS"), 0);
        Question q16 = new Question("Quel modèle réseau comporte 7 couches ?",
                Arrays.asList("Modèle TCP/IP", "Modèle OSI", "Modèle P2P", "Modèle Ethernet"), 1);
        Question q17 = new Question("Que fait une attaque par déni de service (DoS) ?",
                Arrays.asList("Vole des données", "Chiffre des fichiers", "Sature un service en requêtes", "Espionne les utilisateurs"), 2);
        Question q18 = new Question("Quel est le format d’adresse IPv4 ?",
                Arrays.asList("Hexadécimal", "32 bits en décimal", "64 bits en binaire", "Nom symbolique"), 1);
        Question q19 = new Question("Quel outil est utilisé pour gérer des conteneurs applicatifs ?",
                Arrays.asList("Ansible", "Docker", "Jenkins", "Git"), 1);
        Question q20 = new Question("Quel type de logiciel est PostgreSQL ?",
                Arrays.asList("Navigateur", "Système d’exploitation", "SGBD", "Antivirus"), 2);

        return new QuestionBank(Arrays.asList(q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        if (savedInstanceState != null) {
            mScore = savedInstanceState.getInt(BUNDLE_STATE_SCORE);
            mRemainingQuestionCount = savedInstanceState.getInt(BUNDLE_STATE_QUESTION);
        } else {
            mScore = 0;
            mRemainingQuestionCount = 4;
        }

        mQuestionTextView = findViewById(R.id.game_activity_textview_question);
        mAnswerButton1 = findViewById(R.id.game_activity_button_1);
        mAnswerButton2 = findViewById(R.id.game_activity_button_2);
        mAnswerButton3 = findViewById(R.id.game_activity_button_3);
        mAnswerButton4 = findViewById(R.id.game_activity_button_4);

        mAnswerButton1.setOnClickListener(this);
        mAnswerButton2.setOnClickListener(this);
        mAnswerButton3.setOnClickListener(this);
        mAnswerButton4.setOnClickListener(this);

        mCurrentQuestion = mQuestionBank.getCurrentQuestion();
        displayQuestion(mCurrentQuestion);
    }

    private void displayQuestion(final Question question) {
        mQuestionTextView.setText(question.getQuestion());
        mAnswerButton1.setText(question.getChoiceList().get(0));
        mAnswerButton2.setText(question.getChoiceList().get(1));
        mAnswerButton3.setText(question.getChoiceList().get(2));
        mAnswerButton4.setText(question.getChoiceList().get(3));
    }

    @Override
    public void onClick(View v) {
        int index;
        if (v == mAnswerButton1) {
            index = 0;
        } else if (v == mAnswerButton2) {
            index = 1;
        } else if (v == mAnswerButton3) {
            index = 2;
        } else if (v == mAnswerButton4) {
            index = 3;
        } else {
            throw new IllegalStateException("Unknown clicked view : " + v);
        }

        if (index == mCurrentQuestion.getAnswerIndex()) {
            Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
            mScore++;
        } else {
            Toast.makeText(this, "Incorrect!", Toast.LENGTH_SHORT).show();
        }

        mEnableTouchEvents = false;

        new Handler(getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                mEnableTouchEvents = true;
                mRemainingQuestionCount--;
                if (mRemainingQuestionCount > 0) {
                    mCurrentQuestion = mQuestionBank.getNextQuestion();
                    displayQuestion(mCurrentQuestion);
                } else {
                    Intent intent = new Intent();
                    intent.putExtra(BUNDLE_EXTRA_SCORE, mScore);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        }, 2000);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(BUNDLE_STATE_SCORE, mScore);
        outState.putInt(BUNDLE_STATE_QUESTION, mRemainingQuestionCount);
    }
}